package com.monisha.junglebook.project02;

public class Animals {
    private String animalNameT;
    private int image;

    public Animals(String animalNameT, int image){
        //initialize the constructor
        this.animalNameT= animalNameT;
        this.image=image;
    }

    public String getAnimal() {
        return animalNameT;
    }

    public int getImage() {
        return image;
    }


}
