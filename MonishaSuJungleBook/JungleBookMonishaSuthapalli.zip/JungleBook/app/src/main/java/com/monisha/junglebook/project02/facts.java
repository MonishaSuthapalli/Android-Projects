package com.monisha.junglebook.project02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.List;

public class facts extends AppCompatActivity {

    //initialize listview of animals
    ListView list_View;
    List<String> animalsList = new ArrayList<String>();
    ArrayAdapter<String> adaptAn;
    int pos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animals);

        Intent int1=getIntent();
        pos = int1.getExtras().getInt("Index");
        list_View=(ListView) findViewById(R.id.listview1);

        switch(pos)
        {
            case 0:
                animalsList.add("Name:Shere Khan aka Tiger");
                animalsList.add("Average Life Span: 8-10 Years");
                animalsList.add("Weight: 65 to 167 kg ");
                animalsList.add("Preferred Habitat: swamps, savannas, grasslands, and jungle-like rainforests ");
                animalsList.add("Feeding Habbit: Termites to Elephant calves");
                animalsList.add("Endangered Species: Yes");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 1:
                animalsList.add("Name:Bhageera aka Black Panther");
                animalsList.add("Average Life Span: 20-30 Years");
                animalsList.add("Weight: 315 to 770 kg ");
                animalsList.add("Preferred Habitat: forests, mountains, tundra, deserts and grassy areas ");
                animalsList.add("Feeding Habbit: vegetation, insects and other more reliable, though lower calorie food sources.");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 2:
                animalsList.add("Name: Akela_The Indian Wolf");
                animalsList.add("Average Life Span: 8 to 13 Years");
                animalsList.add("Weight: 25 to 36 kg ");
                animalsList.add("Preferred Habitat:  tundra to woodlands, forests, grasslands and deserts ");
                animalsList.add("Feeding Habbit: deer, elk, bison, and moose. They also hunt smaller mammals such as beavers, rodents, and hares.");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 3:
                animalsList.add("Name: Kaa_rock Python Snake");
                animalsList.add("Average Life Span: 20 to 30 Years");
                animalsList.add("Weight: 44 to 55 kg ");
                animalsList.add("Preferred Habitat:  forest, savanna, grassland, semidesert, and rocky areas.");
                animalsList.add("Feeding Habbit: small antelope, warthogs, dogs, monkeys, waterfowl, goats and crocodiles.");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 4:
                animalsList.add("Name: Baloo_Bear");
                animalsList.add("Average Life Span: 20-30 Years");
                animalsList.add("Weight: 315 to 770 kg ");
                animalsList.add("Preferred Habitat: forests, mountains, tundra, deserts and grassy areas ");
                animalsList.add("Feeding Habbit: vegetation, insects and other more reliable, though lower calorie food sources.");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 5:
                animalsList.add("Name: Hathi_The Elephant");
                animalsList.add("Average Life Span: 40-50 Years");
                animalsList.add("Weight: 2,700 and 3,600 kg ");
                animalsList.add("Preferred Habitat: savannahs, forests, deserts, and marshes. ");
                animalsList.add("Feeding Habbit: roots, grasses, fruit, and bark.");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 6:
                animalsList.add("Name: KingLouie_Ape");
                animalsList.add("Average Life Span: 39 Years");
                animalsList.add("Weight: 27 to 70 kg ");
                animalsList.add("Preferred Habitat: Forests (moist and dry forests), Savannah Woodlands, and Grassland-Forest mosaics. ");
                animalsList.add("Feeding Habbit:  fruit, leaves, plant stalks, roots, insects and other vertebrate animals");
                animalsList.add("Endangered Species: No");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;

            case 7:
                animalsList.add("Name: RockyTheRhino_Rhinoceros");
                animalsList.add("Average Life Span: 39 Years");
                animalsList.add("Weight: 1600 to 2400 kg ");
                animalsList.add("Preferred Habitat: Tropical and subtropical grasslands, savannas and shrublands, tropical moist forests, deserts and shrublands  ");
                animalsList.add("Feeding Habbit:  grasses, shoots, leaves, fruits, berries, and buds. ");
                animalsList.add("Endangered Species: Yes, Critically Endangered");
                adaptAn= new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, animalsList);
                list_View.setAdapter(adaptAn);
                break;
        }

    }
}
