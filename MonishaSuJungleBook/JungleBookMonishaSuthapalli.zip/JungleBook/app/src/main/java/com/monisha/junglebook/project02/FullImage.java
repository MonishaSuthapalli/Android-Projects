package com.monisha.junglebook.project02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class FullImage extends AppCompatActivity {

    int key=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_full);

        Intent intent=getIntent();

        key=intent.getExtras().getInt("Index");

        final ImageView img= (ImageView) findViewById(R.id.imgView2);
        img.setImageResource(MainActivity.imgs[key]);

        //opens page on clicking image
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent deal=new Intent(getApplicationContext(), facts.class);
                deal.putExtra("Index", key);
                startActivity(deal);

            }
        });
    }


}
