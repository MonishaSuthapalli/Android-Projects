package com.monisha.junglebook.project02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends BaseAdapter {

    Context c;
    //initiating array list of animal items
    ArrayList<Animals> animalOb;

    public Adapter(Context c,ArrayList<Animals> animalOb){
        this.c=c;
        this.animalOb=animalOb;
    }

    @Override
    public Object getItem(int i) {
        return animalOb.get(i);
    }

    @Override
    public long getItemId(int i) {   //Return the resource reference for item at position
        return 0;
    }

    @Override
    public int getCount() {   //Returns the number of items managed by adapter
        return animalOb.size();
    }



    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflaterObj = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view==null)
            view = inflaterObj.inflate(R.layout.model, viewGroup,false);

        TextView txt= (TextView) view.findViewById(R.id.txtView1);
        ImageView img=(ImageView) view.findViewById(R.id.listT);
        ImageView image =(ImageView) view.findViewById(R.id.imgView1);

        //sets the animal image by the specified id
        image.setImageResource(animalOb.get(i).getImage());
        txt.setText(animalOb.get(i).getAnimal());

        return view;
    }
}

