package com.monisha.junglebook.project02;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView gridView;
    String[] names={"ShareKhan_Tiger","Bagheera_BlackPanther","Akela_IndianWolf","Kaa_Snake","Baloo_Bear","Hathi_Elephant","KingLouie_Ape","RockyTheRhino_Rhinoceros"};


    static final int[] imgs={R.drawable.tiger,R.drawable.blackpanther,R.drawable.wolf,R.drawable.snake,R.drawable.bear,R.drawable.elephant,R.drawable.ape,R.drawable.rhinoceros};
    static final ArrayList<Uri> mUriList= new ArrayList<Uri>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Gridview gets populated this way
        gridView=(GridView) findViewById(R.id.gridView1);

        Adapter adapter=new Adapter(this, getAnimal());
        gridView.setAdapter(adapter);



        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Toast.makeText(getApplicationContext(),names[i],Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getApplicationContext(), FullImage.class);
                intent.putExtra("Index", i);
                startActivity(intent);
            }
        });

        registerForContextMenu(gridView);  //for long click

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        //for long click
        MenuInflater inflater= getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        //on long click
        AdapterView.AdapterContextMenuInfo contextmenu = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        animalURLS();

        if(item.getItemId()==R.id.shortclick)
        {
            Intent intent=new Intent(getApplicationContext(), FullImage.class);
               intent.putExtra("Index", contextmenu.position);
               startActivity(intent);
        }
        else if(item.getItemId()==R.id.web)
        {
            Uri aUri =mUriList.get(contextmenu.position);
                Intent int1 = new Intent(Intent.ACTION_VIEW);
              int1.setData(aUri);
                int1.addCategory(Intent.CATEGORY_BROWSABLE);
               startActivity(int1);
        }
        else if(item.getItemId()==R.id.listT)
        {
            Intent deal=new Intent(getApplicationContext(), facts.class);
            deal.putExtra("Index", contextmenu.position);
            startActivity(deal);
        }
            return super.onContextItemSelected(item);
    }

    private ArrayList<Animals> getAnimal(){
        //arraylist to add respective animal and image
        ArrayList<Animals> animal= new ArrayList<Animals>();
        animal.add(new Animals(names[0],imgs[0]));
        animal.add(new Animals(names[1],imgs[1]));
        animal.add(new Animals(names[2],imgs[2]));
        animal.add(new Animals(names[3],imgs[3]));
        animal.add(new Animals(names[4],imgs[4]));
        animal.add(new Animals(names[5],imgs[5]));
        animal.add(new Animals(names[6],imgs[6]));
        animal.add(new Animals(names[7],imgs[7]));



        return animal;
    }

    static final void animalURLS(){
        //adds all animal websites
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Tiger"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/BlackPanther"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Wolf"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Snake"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Bear"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Elephant"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Ape"));
        mUriList.add(Uri.parse("https://en.wikipedia.org/wiki/Rhinoceros"));
    }
}
